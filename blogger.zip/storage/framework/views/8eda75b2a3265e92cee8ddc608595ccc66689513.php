



<?php $__env->startSection('content'); ?>
    
<div class="container">
    <?php if(session()->get('success')): ?>
        <div class="text-primary h5 text-center py-2">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="d-flex justify-content-end">
        <?php echo e($articals->links()); ?>

    </div>
    <div class="row d-flex justify-content-center">
        <div class="col-md-8">
            <h3 class="text-warning">Articals</h3>
            <div>
                <?php $__currentLoopData = $articals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artical): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card my-4">
                    <div class="card-body ">
                        <div class="card-title fs-5 text-center"> <?php echo e($artical->title); ?> </div>
                        <div class="mt-2 card-subtitle text-secondary text-center"> <?php echo e($artical->created_at->diffForHumans()); ?>  / By <?php echo e($artical->user->name); ?></div>
                        <div class="my-3 card-text text-center"> <?php echo $artical->body; ?> </div>
                        <a class="card-link text-decoration-none" href="/articals/detail/<?php echo e($artical->id); ?>"> View detail &raquo</a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AUNG PHYO HTET\Desktop\blogger\resources\views/articals/index.blade.php ENDPATH**/ ?>