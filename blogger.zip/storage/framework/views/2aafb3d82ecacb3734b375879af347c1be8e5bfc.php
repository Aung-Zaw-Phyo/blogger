<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php if(session()->get('success')): ?>
            <div class="text-primary h5 text-center py-2">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
            <div class="text-center h1 my-3 text-warning">Your Articals</div>
            <?php if(!$articals->count() == 0): ?>
            <?php $__currentLoopData = $articals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artical): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card my-3">
                <div class="card-body ">
                    <div class="card-title fs-5">
                        <?php echo e($artical->title); ?>

                    </div>
                    <div class="card-subtitle">
                        <?php echo e($artical->category->name); ?>

                    </div>
                    <div class="card-subtitle text-secondary my-2">
                        <?php echo e($artical->created_at->diffForHumans()); ?>

                    </div>
                    <div class="">
                        <?php echo $artical->body; ?>

                    </div>
                </div>
                <div class="card-footer d-flex ">
                    <a href="/articals/edit/<?php echo e($artical->id); ?>" class="btn btn-warning mx-2">Edit</a>
                    <form action="/articals/delete/<?php echo e($artical->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                    <a class="card-link text-decoration-none ms-auto" href="/articals/detail/<?php echo e($artical->id); ?>"> View detail &raquo</a>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php echo e($articals->links()); ?>

            
            <?php else: ?>
                <div class="alert alert-info text-center h5 fst-italic">
                    There is no artical you have posted!
                </div>
            <?php endif; ?>




            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AUNG PHYO HTET\Desktop\blogger\resources\views/home.blade.php ENDPATH**/ ?>