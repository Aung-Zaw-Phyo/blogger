



<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <div class="card-title fs-5 text-center">
                            <?php echo e($artical->title); ?>

                        </div>
                        <div class="card-subtitle mt-1 text-secondary text-center">
                            <?php echo e($artical->created_at->diffForHumans()); ?> / By <?php echo e($artical->user->name); ?>

                        </div>
                        <div class="card-subtitle text-secondary text-center">
                            Category: <?php echo e($artical->category->name); ?>

                        </div>
                        <div class="card-text my-2 text-center">
                            <?php echo $artical->body; ?>

                        </div>
                        <div class="d-flex">
                            <a href="<?php echo e(url()->previous()==URL::current() ? "/": url()->previous()); ?>" class="btn btn-warning me-2">Back</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="row d-flex justify-content-center">
            <div class="col-md-8">

                <div class="card p-3 my-2">
                    <?php if(auth()->guard()->check()): ?>
                    <form action="/comments/add" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="artical_id" value="<?php echo e($artical->id); ?>">
                        
                        <div class="mb-3">
                          <label for="exampleInputEmail1" class="form-label">Comment</label>
                          <textarea name="content" class="form-control" id="exampleInputEmail1" cols="10" rows="4" placeholder="Enter message"></textarea> 
                            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"> <?php echo e($message); ?> </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                    <?php else: ?>
                    Please login to participate in thid discussion! <a href="/login">login</a>
                    <?php endif; ?>
                </div>

            </div>
        </div>

        <div class="row d-flex justify-content-center mt-3">
            <div class="col-md-8">
                <ul class="list-group mb-2">
                    <li class="list-group-item active" aria-current="true">Comments <?php echo e($artical->comments->count()); ?></li>
                    <?php $__currentLoopData = $artical->comments()->latest()->paginate(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item"> 
                            <div class="fst-italic fw-bold"><?php echo e($comment->user->name); ?></div>
                            <div class="fst-italic text-secondary"><?php echo e($comment->created_at->diffForHumans()); ?></div>
                            <div class=" d-flex justify-content-between mt-2">
                                <div class="text-primary"><?php echo e($comment->content); ?></div>
                                <?php if(Gate::allows('comment', $comment)): ?>
                                <a href="/comments/delete/<?php echo e($comment->id); ?>" class="btn btn-close"></a>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php echo e($artical->comments()->latest()->paginate(5)->links()); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AUNG PHYO HTET\Desktop\blogger\resources\views/articals/detail.blade.php ENDPATH**/ ?>